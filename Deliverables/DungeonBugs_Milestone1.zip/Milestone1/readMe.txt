Dungeon Bugs!

This is a 2D turn-based RPG game where bugs with special abilities battle each other.

Use the mouse to click on any of your units, then click any location highlighted 
to confirm their movement.

Use the unit info UI to also choose an ability to attack. 
Confirm an attack by pressing on any space that has another unit.

Objective:
Defeat all of the enemies! 

Enjoy!