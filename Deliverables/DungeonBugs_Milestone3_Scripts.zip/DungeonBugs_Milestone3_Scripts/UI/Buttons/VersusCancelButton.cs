//Joshara Edwards (2022)

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VersusCancelButton : DBButton
{
    private void Start()
    {
        Setup();
    }
}
