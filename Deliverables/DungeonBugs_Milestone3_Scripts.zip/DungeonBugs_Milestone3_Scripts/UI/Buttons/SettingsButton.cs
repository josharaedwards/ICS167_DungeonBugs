//Joshara Edwards (2022)

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SettingsButton : DBButton
{
    void Start()
    {
        Setup();
    }
}
