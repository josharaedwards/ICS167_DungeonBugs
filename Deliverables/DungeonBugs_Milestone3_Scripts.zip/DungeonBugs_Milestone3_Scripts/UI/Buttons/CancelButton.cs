//Joshara Edwards (2022)

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CancelButton : DBButton
{
    void Start()
    {
        Setup();
    }
}
