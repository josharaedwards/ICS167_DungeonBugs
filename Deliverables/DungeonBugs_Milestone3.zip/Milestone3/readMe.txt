Dungeon Bugs!

This is a 2D turn-based RPG game where bugs with special abilities battle each other.

Use the mouse to left-click on any of your units, then click any location highlighted 
to confirm their movement.

Right-click to cancel using an ability or movement.

Use the unit info UI to also choose an ability to attack. 
Confirm an attack by pressing on any space that has another unit.

Use WASD to move the camera and the mouse wheel to zoom in/out.

Objective:
Defeat all of the enemies! 

Enjoy!